"""This is the setup file for create the package for HierarchyPrintData.py"""

from distutils.core import setup

setup(
        name = 'PrintHierarchyData',
        version= '1.0.0',
        py_modules = ['PrintHierarchyData'],
        author = 'Rakesh',
        author_email = 'rockyshetty2006@gmil.com',
        url = '',
        description = 'This is the test package created for learing purpose',
    )
