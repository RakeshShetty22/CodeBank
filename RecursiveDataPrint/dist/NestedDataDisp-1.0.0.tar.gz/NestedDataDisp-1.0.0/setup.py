from distutils.core import setup

setup(
        name = 'NestedDataDisp',
        version = '1.0.0',
        py_modules = ['RecursiveDataPrinter'],
        author = 'xyz',
        author_email = 'rakesh@gmail.comavc',
        url = 'http://www.testurl.com/',
        description = 'test desp'
     )
